https://medium.com/analytics-vidhya/activation-functions-all-you-need-to-know-355a850d025e

Cnn:-
https://medium.com/@mouneshpatil001/e2b458307dfb


Data Augumentation:

https://medium.com/analytics-vidhya/data-augmentation-techniques-using-opencv-657bcb9cc30b


https://research.aimultiple.com/data-augmentation-techniques/

Optimization:-
https://towardsdatascience.com/deep-learning-optimizers-436171c9e23f

https://www.codingninjas.com/studio/library/nesterov-accelerated-gradient


Hyperparameter:

https://medium.com/analytics-vidhya/hyperparameter-tuning-using-keras-tuner-72a8cb394d0f

Pre-traineed Model:-https://medium.com/@mouneshpatil001/transfer-learning-using-pre-trained-models-for-image-classification-resnet50-in-keras-b96967c5f124

Lenet
https://medium.com/codex/lenet-5-complete-architecture-84c6d08215f9
